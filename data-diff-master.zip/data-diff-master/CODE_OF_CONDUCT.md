Treat everyone with respect and patience.
